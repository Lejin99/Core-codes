function [u,g_grid_in,g_pv_in,g_out ] = new_month_schedule_pv(depot,panel_area,lamda_peak,elec_price,feed_in_tariff,depot_load_pv_mat,pv_day_month_small,C_rate,capacity_storage_depot)
life_list = [1,0.975000000000000,0.950000000000000,0.925000000000000,0.900000000000000,0.875000000000000,0.850000000000000,0.825000000000000,0.800000000000000,0.775000000000000,1,0.975000000000000,0.950000000000000,0.925000000000000,0.900000000000000,0.875000000000000,0.850000000000000,0.825000000000000,0.800000000000000,0.775000000000000,1,0.975000000000000,0.950000000000000,0.925000000000000,0.900000000000000];

capacity_storage = capacity_storage_depot(depot);
pv_produce_base = zeros(25,12,1440);

capacity_storage_mat = zeros(25,12);
for i = 1:25
    for j = 1:12
        capacity_storage_mat(i,j) = capacity_storage*life_list(i);
    end
end


for i = 1:25
    for j = 1:12
         pv_produce_base(i,j,:) = (1-0.005*(i - 1))*(pv_day_month_small(j,:)*0.8*panel_area(depot)/0.777/1.62)/1000/60;
    end
end


p_t = zeros(25,12,1440);
for i = 1:25
    for j = 1:12
          p_t(i,j,:) =  depot_load_pv_mat(j,:);
    end
end




p_max  = sdpvar(25,12,'full');
u = sdpvar(25,12,1440,'full');
E = sdpvar(25,12,1440,'full');
z_in = binvar(25,12,1440,'full');
z_out = binvar(25,12,1440,'full');
g_grid_in = sdpvar(25,12,1440,'full');
g_pv_in = sdpvar(25,12,1440,'full');
g_out = sdpvar(25,12,1440,'full');









objective = 0;
objective = objective + lamda_peak*sum(sum(p_max));


elec_price_time = zeros(1,1440);
for i = 1:96
    elec_price_time( (i - 1)*15 + 1:i*15) = elec_price(i);
end

elec_price_mat = zeros(25,12,1440);
for i = 1:25
    for j = 1:12
          elec_price_mat(i,j,:) = elec_price_time;
    end
end

objective = objective + sum(sum(sum(elec_price_mat.*g_grid_in)));
objective = objective - sum(sum(sum(elec_price_mat.*u +  0.9*elec_price_mat.*g_out +  feed_in_tariff.*(pv_produce_base - u - g_pv_in))));




yueshu = [];
yueshu = [yueshu, u >= 0];
yueshu = [yueshu, p_max >= 0];
yueshu = [yueshu, E >= 0];
yueshu = [yueshu, g_grid_in >= 0];
yueshu = [yueshu, g_pv_in >= 0];
yueshu = [yueshu, g_out >= 0];


yueshu = [yueshu, u <= (1/60)*p_t];
yueshu = [yueshu, u <= pv_produce_base];
yueshu = [yueshu,repmat(p_max,1,1,1440) >= p_t - (60*u)  -   0.9*(60*g_out) + 60*g_grid_in ];


for t = 1:1440
    if t == 1
       yueshu = [yueshu, E(:,:,t) == capacity_storage_mat + 0.9*g_grid_in(:,:,t) + 0.9*g_pv_in(:,:,t) - g_out(:,:,t)  ]; 
    else
       yueshu = [yueshu, E(:,:,t) == E(:,:,t - 1)  + 0.9*g_grid_in(:,:,t) + 0.9*g_pv_in(:,:,t) - g_out(:,:,t)  ];  
    end       
end
yueshu = [yueshu, E(:,:,1440) == capacity_storage_mat];


yueshu = [yueshu, E >= 0.2*repmat(capacity_storage_mat,1,1,1440)   ];
yueshu = [yueshu, E <= repmat(capacity_storage_mat,1,1,1440)   ];
yueshu = [yueshu, g_pv_in <= pv_produce_base - u   ];
yueshu = [yueshu, g_pv_in +  g_grid_in <= C_rate*repmat(capacity_storage_mat,1,1,1440)*(1/60)   ];
yueshu = [yueshu,  0.9*g_out + u <=   (1/60)*p_t];
yueshu = [yueshu, g_out <=  C_rate*repmat(capacity_storage_mat,1,1,1440)*(1/60)   ];
yueshu = [yueshu, g_pv_in +  g_grid_in <= 10000000*z_in];
yueshu = [yueshu, g_out <= 10000000*z_out];
yueshu = [yueshu, z_in + z_out <= 1 ];







ops = sdpsettings('solver','+gurobi');
%ops.verbose = 0;
ops.gurobi.TimeLimit = 300;
ops.gurobi.MIPGap = 1.0000e-03;
sol = optimize(yueshu,objective,ops);


u = double(u);
g_grid_in = double(g_grid_in);
g_pv_in = double(g_pv_in);
g_out = double(g_out);

     
            
            
            
            
