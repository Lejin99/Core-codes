pv_day_month_small = zeros(12,1440);
for i = 1:12
    for j = 1:1440
        pv_day_month_small(i,j) = pv_day_month(i, (j - 1)*60 + 1);
    end
end

depot_pv_use_cell = {};
depot_load_pv_cell = {};
year = 1;
capacity_storage_depot = zeros(1,678);
depot_area_list = zeros(1,678);


%%%%%%%%%%%%%%%%%%%%%%%%%%%
C_rate = 10;
for i = 604:678
    i
    if~isempty(depot_vehicle_base{i})
        
         pv_produce_base = (1-0.005*(year-1))*(pv_day_month_small*0.8*panel_area(i)/0.777/1.62)/1000/60;
        [mat,capacity_storage,pv_area] = bus_charging_schedule_depot(lamda_peak,i,depot_vehicle_base,elec_price,power,charger_num_depot,feed_in_tariff,pv_produce_base,unit_storage_cost,C_rate,panel_area);
        capacity_storage_depot(i) = capacity_storage;
        csvwrite(char('E:\NE计算结果文件\光伏+无补贴+有储能\data-load\' + string(i) + '.csv') , mat);
        csvwrite(char('E:\NE计算结果文件\光伏+无补贴+有储能\area\' + string(i) + '.csv') ,pv_area);
        csvwrite(char('E:\NE计算结果文件\光伏+无补贴+有储能\storage_capacity\' + string(i) + '.csv') ,capacity_storage);
       
        [mat1,mat2,mat3,mat4] = new_month_schedule_pv(i,lamda_peak,elec_price,feed_in_tariff,mat,pv_day_month_small,C_rate,capacity_storage_depot,pv_area);
        for j = 1:25
           
            for m = 1:12
                mat_base1(m,:) =  reshape(mat1(j,m,1:1440),1,1440);
                mat_base2(m,:) =  reshape(mat2(j,m,1:1440),1,1440);
                mat_base3(m,:) =  reshape(mat3(j,m,1:1440),1,1440);
                mat_base4(m,:) =  reshape(mat4(j,m,1:1440),1,1440);
            end
            csvwrite(char('E:\NE计算结果文件\光伏+无补贴+有储能\data-pv\' + string(i) + 'and' + string(j) + '.csv') , mat_base1);  
            csvwrite(char('E:\NE计算结果文件\光伏+无补贴+有储能\data-g_grid_in\' + string(i) + 'and' + string(j) + '.csv') , mat_base2);  
            csvwrite(char('E:\NE计算结果文件\光伏+无补贴+有储能\data-g_pv_in\' + string(i) + 'and' + string(j) + '.csv') , mat_base3); 
            csvwrite(char('E:\NE计算结果文件\光伏+无补贴+有储能\data-g_out\' + string(i) + 'and' + string(j) + '.csv') , mat_base4);  
        end
    end
    if isempty(depot_vehicle_base{i})
        csvwrite(char('E:\NE计算结果文件\光伏+无补贴+有储能\storage_capacity\' + string(i) + '.csv') ,0);
       
        mat = zeros(12,1440);
        csvwrite(char('E:\NE计算结果文件\光伏+无补贴+有储能\data-load\' + string(i) + '.csv') , mat);  
        csvwrite(char('E:\NE计算结果文件\光伏+无补贴+有储能\area\' + string(i) + '.csv') ,0);
        [mat1,mat2,mat3,mat4] = new_month_schedule_pv(i,lamda_peak,elec_price,feed_in_tariff,mat,pv_day_month_small,C_rate,capacity_storage_depot,0);
        for j = 1:25
            
            for m = 1:12
                mat_base1(m,:) =  reshape(mat1(j,m,1:1440),1,1440);
                mat_base2(m,:) =  reshape(mat2(j,m,1:1440),1,1440);
                mat_base3(m,:) =  reshape(mat3(j,m,1:1440),1,1440);
                mat_base4(m,:) =  reshape(mat4(j,m,1:1440),1,1440);
            end
            csvwrite(char('E:\NE计算结果文件\光伏+无补贴+有储能\data-pv\' + string(i) + 'and' + string(j) + '.csv') , mat_base1);  
            csvwrite(char('E:\NE计算结果文件\光伏+无补贴+有储能\data-g_grid_in\' + string(i) + 'and' + string(j) + '.csv') , mat_base2);  
            csvwrite(char('E:\NE计算结果文件\光伏+无补贴+有储能\data-g_pv_in\' + string(i) + 'and' + string(j) + '.csv') , mat_base3); 
            csvwrite(char('E:\NE计算结果文件\光伏+无补贴+有储能\data-g_out\' + string(i) + 'and' + string(j) + '.csv') , mat_base4);  
        end
    end
    fclose('all')
end








