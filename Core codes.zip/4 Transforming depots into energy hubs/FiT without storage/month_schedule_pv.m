function [p_t,u] = month_schedule_pv(month,lamda_peak,depot,depot_vehicle_base,delta,delta_time,elec_price,power,delta_dot,charger_num_depot,feed_in_tariff,pv_produce_base)


event_mat = depot_vehicle_base{depot};


x = binvar(size(event_mat,1),96,'full');
q = sdpvar(size(event_mat,1),96,'full');
p_kj = sdpvar(size(event_mat,1),96,'full');              
p_t = sdpvar(1,1440);
p_max  = sdpvar(1,1);
u = sdpvar(1,1440);

objective = 0;
objective = objective + lamda_peak*p_max;



elec_price_mat = zeros(size(event_mat,1),96);
for  i = 1:size(event_mat,1)
    for j = 1:96
        elec_price_mat(i,j) = elec_price(j);
    end
end

objective = objective + sum(sum(elec_price_mat.*q));


elec_price_time = zeros(1,1440);
for i = 1:96
    elec_price_time( (i - 1)*15 + 1:i*15) = elec_price(i);
end


objective = objective - sum(elec_price_time.*u + feed_in_tariff.*(pv_produce_base(month,:) - u));


yueshu = [];
yueshu = [yueshu,x <= delta];
yueshu = [yueshu, q >= 0];
yueshu = [yueshu, p_kj >= 0];
yueshu = [yueshu, p_t >= 0];
yueshu = [yueshu, u >= 0];
yueshu = [yueshu, p_max >= 0];
yueshu = [yueshu, sum(q,2) == event_mat(:,2 + month)];
yueshu = [yueshu, q == (1/60)*delta_time.*p_kj];
yueshu = [yueshu, p_kj <= power*x];





for t = 1:1440
   yueshu = [yueshu, p_t(t) == sum(sum(delta_dot(:,:,t).*p_kj))  ]; 
end







yueshu = [yueshu, p_kj <= power*x];
%yueshu = [yueshu, p_j == sum(p_kj,1) ];
yueshu = [yueshu, sum(x,1) <= charger_num_depot(depot)];

yueshu = [yueshu, u <= (1/60)*p_t];
yueshu = [yueshu, u <= pv_produce_base(month,:)];

yueshu = [yueshu, p_max >= p_t - u/(1/60)];
ops = sdpsettings('solver','+gurobi');
ops.gurobi.TimeLimit = 300;
ops.gurobi.MIPGap = 1.0000e-03;
sol = optimize(yueshu,objective,ops);

p_t = double(p_t);
u = double(u);

     
            
            
            
            
