function [u] = new_month_schedule_pv(panel_area,month,lamda_peak,elec_price,feed_in_tariff,depot_load_pv_cell,year,depot_vehicle_base,pv_day_month_small)

pv_produce_base = zeros(678,1440);

for i = 1:678
    if~isempty(depot_vehicle_base{i})
        pv_produce_base(i,:) = (1-0.005*(year-1))*(pv_day_month_small(month,:)*0.8*panel_area(i)/0.777/1.62)/1000/60;
    else
        pv_produce_base(i,:) = zeros(1,1440);
    end
end



p_t = zeros(678,1440);

for i = 1:678
    if~isempty(depot_vehicle_base{i})
        mat = depot_load_pv_cell{i};
        p_t(i,:) =  mat(month,:);
    else
        p_t(i,:) = zeros(1,1440);
    end
end




p_max  = sdpvar(678,1,'full');
u = sdpvar(678,1440,'full');

objective = 0;
objective = objective + lamda_peak*sum(p_max);


elec_price_time = zeros(1,1440);
for i = 1:96
    elec_price_time( (i - 1)*15 + 1:i*15) = elec_price(i);
end

elec_price_mat = zeros(678,1440);
for i = 1:678
    elec_price_mat(i,:) = elec_price_time;
end



objective = objective - sum(sum(elec_price_mat.*u + feed_in_tariff*( pv_produce_base - u)));


yueshu = [];
yueshu = [yueshu, u >= 0];
yueshu = [yueshu, p_max >= 0];
yueshu = [yueshu, u <= (1/60)*p_t];
yueshu = [yueshu, u <= pv_produce_base];
yueshu = [yueshu, repmat(p_max,1,1440) >= p_t - 60*u];







ops = sdpsettings('solver','+gurobi');
ops.verbose = 0;
ops.gurobi.TimeLimit = 300;
ops.gurobi.MIPGap = 1.0000e-03;
sol = optimize(yueshu,objective,ops);


u = double(u);

     
            
            
            
            
