pv_day_month_small = zeros(12,1440);
for i = 1:12
    for j = 1:1440
        pv_day_month_small(i,j) = pv_day_month(i, (j - 1)*60 + 1);
    end
end

depot_pv_use_cell = {};
depot_load_pv_cell = {};
depot_area_list = zeros(1,678);
for i = 1:678
    i
    if~isempty(depot_vehicle_base{i})
        [depot_load_pv,depot_pv_use,depot_area] =  bus_charging_schedule_depot(lamda_peak,i,depot_vehicle_base,elec_price,power,charger_num_depot,feed_in_tariff,pv_day_month_small,panel_area);
        depot_load_pv_cell{i} = depot_load_pv;
        depot_pv_use_cell{i} = depot_pv_use;
        depot_area_list(i) = depot_area;
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i = 1:678
    if isempty(depot_vehicle_base{i})
        depot_load_pv_cell{i} = zeros(12,1440);
    end
end

for i = 1:678
    mat = depot_load_pv_cell{i};
    csvwrite(char('C:\Users\111\Desktop\光伏+无补贴+无储能\data-load\' + string(i) + '.csv') , mat);  %%%% 要存起来
end

depot_pv_use_cell_year ={};
for i = 1:25
    for j = 1:12
        depot_pv_use_cell_year{i,j} = [];
    end
end



for i = 1:25
    i
    for j = 1:12
        j
        depot_pv_use_cell_year{i,j} = new_month_schedule_pv(depot_area_list,j,lamda_peak,elec_price,feed_in_tariff,depot_load_pv_cell,i,depot_vehicle_base,pv_day_month_small);
    end
end

for i = 1:678
    for j = 1:25
        mat_base = zeros(12,1440);
        for m = 1:12
            mat = depot_pv_use_cell_year{j,m};
            mat_base(m,:) =  mat(i,:);
        end
        csvwrite(char('C:\Users\111\Desktop\光伏+无补贴+无储能\data-pv\' + string(i) + 'and' + string(j) + '.csv') , mat_base);  %%%% 要存起来
    end
end

depot_pv_use_cell_year = {};
        
        









