%% Input vehicle_cell ; Capacity_list_cell 
%% charging_shedule ; Output Bus charging schedule (at trip level, not the final charging schedules)
solution_cell = {};
cost_mat = zeros(100,3);
for i = 1:100
    
    cost_mat(i,1) = 1001;
    cost_mat(i,2) = 301;
    cost_mat(i,3) = 73000;
end

for i = 1:100            %%%%%%%%%%%%  
    list1 = zeros(1,20992);
    for j = 1:20992
        mat_count= battery_count_list_cell{j};
        mat_capacity =  Capacity_list_cell{j};
        mat_vehicle = vehicle_cell{j};
        min_cost = 100000000000;
        index = -1;
        for k = 1:length(mat_count)
            if mat_count(k) > 0
               total_cost =  mat_capacity(k)*cost_mat(i,1)+ mat_capacity(k)*(mat_count(k) - 1)*(cost_mat(i,1) - cost_mat(i,2)) + mat_vehicle*bus_length(j)*cost_mat(i,3);      
               if  total_cost < min_cost
                   min_cost = total_cost;
                   index = k;
               end
            end
        end
        list1(j) = index;
    end
    solution_cell{i} = list1;
end
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  %  80% capacity  
list_error = [];
list2= solution_cell{1}; 
charging_shedule  = {};
random_capcity_list = zeros(1,20992);
for i = 1:20992
    i
    filename = ['xxx\xxx\schedule_data1\' , char(bus_id(i)) ,   '.csv'];
    index = list2(i);
    if index == -1
        continue
    end
    data = csvread(filename,1); 
    mat_vehicle = vehicle_cell{i};
    mat_capacity =  Capacity_list_cell{i};
    random_capcity_list(i) = mat_vehicle*mat_capacity(index)*(1  - rand()*0.2);
    [biaoshi, cell_new] = charging_schedule_worse_new(mat_vehicle,random_capcity_list(i),data,energy_adjustment,power);
    charging_shedule{i} = cell_new;
    if biaoshi  == 0
       random_capcity_list(i) = mat_vehicle*mat_capacity(index)*0.8;
       [biaoshi, cell_new] = charging_schedule_worse_new(mat_vehicle,random_capcity_list(i),data,energy_adjustment,power);
    end
    charging_shedule{i} = cell_new;
end







