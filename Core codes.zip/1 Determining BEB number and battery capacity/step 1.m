
vehicle_cell = {}; % The number of BEBs required for each bus
Capacity_list_cell = {}; % The optimal capacity for each bus
battery_count_list_cell = {}; % The number of batteries required for each bus  
for i = 1:20992
    filename = 'E:\xxx\xxx\schedule_data1\' + string(bus_id(i)) +   '.csv'; % The schedule data1 records the all trips and energy consumption for each bus 
    [vehicle,battery_count_list,Capacity_list] = bus_electrification(power,filename,urban_index,energy_adjustment);
    vehicle_cell{i} = vehicle;
    Capacity_list_cell{i} = Capacity_list;
    battery_count_list_cell{i} = battery_count_list;
end

