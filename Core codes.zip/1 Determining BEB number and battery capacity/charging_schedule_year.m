function [Capacity] = charging_schedule_year(vehicle,cell1,max_num,Capacity,data,power,energy_adjustment)



C = Capacity;
biaoshi = 1;

E = zeros(1,size(data,1));
E_pie = zeros(1,size(data,1));

current = C ;
for i = 1: size(data,1)
    current = current - data(i,8)*energy_adjustment(12);
    E(i) =  current;
    if current < 0.2*C
       biaoshi = 0;
       break
    else
       add_energy = min( (vehicle*data(i,4)/3600)*power, C - current) ;
       current = current + add_energy;
       E_pie(i) =  current;
       if i == size(data,1)
           if current < C
               biaoshi = 0;
               break
           end
       end
      
       mat = cell1{i};
      
       for j = 1:max_num
           if sum(  mat(j,:) ) > 0
              if  vehicle*mat(j,3) >= add_energy
                  
                  break
              else
                  add_energy = add_energy -  vehicle*mat(j,3); 
              end
           end
       end
    end
     
end






Energy_list = [];
Energy_list(1) = C;
for i = 1:length(cell1)
    Energy_list = [Energy_list,double(E(i)),double(E_pie(i))];
end
    
fade_couple =[];
while true
    if length(Energy_list) < 3
        break
    end
    index = 0;
    for i = 2:length(Energy_list) - 1
        if Energy_list(i) < Energy_list(i-1) && Energy_list(i) < Energy_list(i+1)
            max_value = max(Energy_list(1:i) );
            min_value = min(Energy_list(1:i) );
            fade_couple =[fade_couple;max_value,min_value];
            Energy_list = Energy_list(i+1:length(Energy_list));
            index = 1;
            break
        end
    end
    if index == 0
        break
    end
end

gama1 = -4.09e-4;
gama2 = -2.167;
gama3 = 1.418e-5;
gama4 = 6.13;

fade_cap_worse = 0;

for i = 1:size(fade_couple,1)
    soc_avg = ( (fade_couple(i,1)/C) + (fade_couple(i,2)/C)   )/2;
    soc_dev = ( (fade_couple(i,1)/C) - (fade_couple(i,2)/C)   )/2;
    delta = gama1*soc_dev*exp(gama2*soc_avg) + gama3*exp(gama4*soc_dev);
    fade_cap_worse = fade_cap_worse  + 31*2*delta *(fade_couple(i,1) - fade_couple(i,2));  
end
   


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


if biaoshi == 1
    fade_cap_other = zeros(1,11);
    for m = 1:11
        C = Capacity;
        %objective = 0;
        biaoshi = 1;
        E = zeros(1,size(data,1));
        E_pie = zeros(1,size(data,1));
        current = C ;
        for i = 1: size(data,1)
            current = current - data(i,8)*energy_adjustment(m);
            E(i) =  current;
            if current < 0.2*C
                biaoshi = 0;
                break
            else
                add_energy = min( (vehicle*data(i,4)/3600)*power, C - current) ;
                current = current + add_energy;
                E_pie(i) =  current;
                if i == size(data,1)
                    if current < C
                        biaoshi = 0;
                        break
                    end
                end
                
                mat = cell1{i};
                
                
                for j = 1:max_num
                    if sum( mat(j,:) ) > 0
                        if  vehicle*mat(j,3) >= add_energy
                            
                            break
                        else
                           
                            add_energy = add_energy -  vehicle*mat(j,3);
                        end
                    end
                end
            end
          
        end
       
       
        Energy_list = [];
        Energy_list(1) = C;
        for i = 1:length(cell1)
            Energy_list = [Energy_list,double(E(i)),double(E_pie(i))];
        end
        
        fade_couple =[]; 
        while true
            if length(Energy_list) < 3
                break
            end
            index = 0;
            for i = 2:length(Energy_list) - 1
                if Energy_list(i) < Energy_list(i-1) && Energy_list(i) < Energy_list(i+1)
                    max_value = max(Energy_list(1:i) );
                    min_value = min(Energy_list(1:i) );
                    fade_couple =[fade_couple;max_value,min_value];
                    Energy_list = Energy_list(i+1:length(Energy_list));
                    index = 1;
                    break
                end
            end
            if index == 0
                break
            end
        end
        
   
        for i = 1:size(fade_couple,1)
            soc_avg = ( (fade_couple(i,1)/C) + (fade_couple(i,2)/C)   )/2;
            soc_dev = ( (fade_couple(i,1)/C) - (fade_couple(i,2)/C)   )/2;
            delta = gama1*soc_dev*exp(gama2*soc_avg) + gama3*exp(gama4*soc_dev);
            fade_cap_other(m) =  fade_cap_other(m) + 30*2*delta*(fade_couple(i,1) - fade_couple(i,2));
        end
    end
end



if biaoshi == 0
    Capacity = 0;
else
    Capacity = Capacity - sum(fade_cap_other) - fade_cap_worse;
end
     
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  