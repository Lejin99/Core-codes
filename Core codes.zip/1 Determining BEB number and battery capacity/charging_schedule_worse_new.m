function [biaoshi, cell_new] = charging_schedule_worse_new(vehicle,Capacity,data,energy_adjustment,power)
biaoshi = 1;
C = Capacity;
current = C;
cell_new = {};

for m = 1:12
    for i = 1: size(data,1)
        current = current - data(i,8)*energy_adjustment(m); %%% energy_adjustment is a adjustment factor list to get BEB energy consumption for each month
        if current < 0.2*C
            biaoshi = 0;
            break
        else
            add_energy = min( (vehicle*data(i,4)/3600)*power, C - current) ;
            current = current + add_energy;
            if i == size(data,1)
                if current < C
                    biaoshi = 0;
                    break
                end
            end
            data(i,9) = add_energy; 
        end 
    end
    cell_new{m} = data;
    if biaoshi == 0
        break
    end
end












