function [biaoshi] = charging_schedule_worse(vehicle,cell1,max_num,Capacity,data,power,energy_adjustment)

biaoshi = 1;
C = Capacity*0.8;
current = C;
for i = 1: size(data,1)
    current = current - data(i,8)*energy_adjustment(12);
    if current < 0.2*C
       biaoshi = 0;
       break
    else
       add_energy = min( (vehicle*data(i,4)/3600)*power, C - current) ;
       current = current + add_energy;
       if i == size(data,1)
           if current < C
               biaoshi = 0;
               break
           end
       end
       mat = cell1{i};
       
       for j = 1:max_num
           if sum( mat(j,:) ) > 0
              if  vehicle*mat(j,3) >= add_energy  
                  break
              else
                  add_energy = add_energy -  vehicle*mat(j,3); 
              end
           end
       end
    end
end


if biaoshi == 1
    current = C;
    for m = 1:11
        for i = 1: size(data,1)
            current = current - data(i,8)*energy_adjustment(m);
            if current < 0.2*C
                biaoshi = 0;
                break
            else
                add_energy = min( (vehicle*data(i,4)/3600)*power, C - current) ;
                current = current + add_energy;
                if i == size(data,1)
                    if current < C
                        biaoshi = 0;
                        break
                    end
                end
                mat = cell1{i};
                
                for j = 1:max_num
                    if sum( mat(j,:) ) > 0
                        if  vehicle*mat(j,3) >= add_energy
                            break
                        else
                            add_energy = add_energy -   vehicle*mat(j,3);
                        end
                    end
                end
            end
        end
    end 
end
















