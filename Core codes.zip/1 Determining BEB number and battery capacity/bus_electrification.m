function [vehicle,battery_count_list,Capacity_list] = bus_electrification(power,filename,urban_index,energy_adjustment)
data = csvread(filename,1);

cell1 = {};
TOU = [18000,25199,0.677000000000000,0.667000000000000;25200,35999,0.677000000000000,0.667000000000000;36000,53999,0.677000000000000,0.667000000000000;54000,64799,0.677000000000000,0.667000000000000;64800,75599,0.677000000000000,0.667000000000000;75600,82799,0.677000000000000,0.667000000000000;82800,86399,0.677000000000000,0.667000000000000;0,17999,0.677000000000000,0.667000000000000];
for i = 1:size(data,1)
    list1 = [];
    if data(i,2) < data(i,3)
        xxx = [data(i,2),data(i,3)];
        while true
            for  k = 1:size(TOU,1)
                if xxx(1) >= TOU(k,1) && xxx(1) <= TOU(k,2)
                    break
                end
            end
            if  xxx(2) <=  TOU(k,2)
                list1 = [list1 ;xxx(1),xxx(2),  (xxx(2) - xxx(1) )*power*(1/3600),urban_index( data(i,5))*TOU(k,3) +  ( 1 - urban_index( data(i,5)) )*TOU(k,4)  ];
                break
            end
            if  xxx(2) >  TOU(k,2)
                list1 = [list1 ;xxx(1), TOU(k,2),  (TOU(k,2) - xxx(1) )*power*(1/3600), urban_index( data(i,5))*TOU(k,3) +  ( 1 - urban_index( data(i,5)) )*TOU(k,4) ];
                xxx = [TOU(k,2)+1,data(i,3)];
            end
        end
        cell1{i} = list1;
    end
    if data(i,2) > data(i,3)
        xxx = [data(i,2),86399];
        while true
            for  k = 1:size(TOU,1)
                if xxx(1) >= TOU(k,1) && xxx(1) <= TOU(k,2)
                    break
                end
            end
            if  xxx(2) <=  TOU(k,2)
                list1 = [list1 ;xxx(1),xxx(2),  (xxx(2) - xxx(1) )*power*(1/3600),urban_index( data(i,5))*TOU(k,3) +  ( 1 - urban_index( data(i,5)) )*TOU(k,4)  ];
                break
            end
            if  xxx(2) >  TOU(k,2)
                list1 = [list1 ;xxx(1), TOU(k,2),  (TOU(k,2) - xxx(1) )*power*(1/3600), urban_index( data(i,5))*TOU(k,3) +  ( 1 - urban_index( data(i,5)) )*TOU(k,4) ];
                xxx = [TOU(k,2)+1,86399];
            end
        end
        xxx = [0,data(i,3)];
        while true
            for  k = 1:size(TOU,1)
                if xxx(1) >= TOU(k,1) && xxx(1) <= TOU(k,2)
                    break
                end
            end
            if  xxx(2) <=  TOU(k,2)
                list1 = [list1 ;xxx(1),xxx(2),  (xxx(2) - xxx(1) )*power*(1/3600),urban_index( data(i,5))*TOU(k,3) +  ( 1 - urban_index( data(i,5)) )*TOU(k,4)  ];
                break
            end
            if  xxx(2) >  TOU(k,2)
                list1 = [list1 ;xxx(1), TOU(k,2),  (TOU(k,2) - xxx(1))*power*(1/3600), urban_index( data(i,5))*TOU(k,3) +  ( 1 - urban_index( data(i,5)) )*TOU(k,4) ];
                xxx = [TOU(k,2)+1,data(i,3)];
            end
        end
        cell1{i} = list1;
        
    end
end

max_num = -1;
for i = 1:length(cell1)
    if size(cell1{i},1) > max_num
        max_num =  size(cell1{i},1);
    end
end

for i = 1:length(cell1)
    if size(cell1{i},1) < max_num
        xxx = cell1{i};
        xxx =[xxx;zeros(max_num -  size(cell1{i},1),4)];
        cell1{i} = xxx;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Capacity_list = [100,150,200,250,300,350]; 
vehicle = 1;
biaoshi_list = [];

for i = 1:6
    [biaoshi] = charging_schedule_worse(vehicle,cell1,max_num,Capacity_list(i),data,power,energy_adjustment);   %% Real battery capacity = 80%
    biaoshi_list(i) = biaoshi;
end



if sum(biaoshi_list) >= 1
    vehicle = 1;
    battery_count_list = zeros(1,6);
    for i = 1:6
        if biaoshi_list(i) == 1
           battery_count = 1;
          
           cap_dynamic = Capacity_list(i);
           
           for y = 1:13
                if cap_dynamic  < 0.8*Capacity_list(i)
                   battery_count = battery_count + 1;
                   cap_dynamic = Capacity_list(i);
                end
                [cap_dynamic] = charging_schedule_year(vehicle,cell1,max_num,cap_dynamic,data,power,energy_adjustment);
   
           end     
           
           battery_count_list(i) = battery_count ;  
        end
    end
  
end
        
if sum(biaoshi_list) == 0
    vehicle = 2;
    while true
        if  vehicle > 10
            battery_count_list = zeros(1,7);
            break
        end
        Capacity_list = zeros(1,7);
        for i = 1:7
            Capacity_list(i) = 350*(vehicle - 1) + 50  + 50*(i-1);
        end
        biaoshi_list1 = [];
        cell_new_list ={};
        for i = 1:7
            [biaoshi1] = charging_schedule_worse(vehicle,cell1,max_num,Capacity_list(i),data,power,energy_adjustment);   %% 80%
            biaoshi_list1(i) = biaoshi1;
        end
        if sum(biaoshi_list1) >= 1
            battery_count_list = zeros(1,7);
            for i = 1:7
                if biaoshi_list1(i) == 1
                    battery_count = 1;
                   
                    cap_dynamic = Capacity_list(i);
                    for y = 1:13
                        if cap_dynamic  < 0.8*Capacity_list(i)
                            battery_count = battery_count + 1;
                            cap_dynamic = Capacity_list(i);
                        end
                        [cap_dynamic] = charging_schedule_year(vehicle,cell1,max_num,cap_dynamic,data,power,energy_adjustment);      
                    end
                    battery_count_list(i) = battery_count ;  
                end
            end
            break
        else
            vehicle = vehicle + 1;
        end
    end
end

       