function [p_t,ss] = month_schedule(month,lamda_peak,depot,depot_vehicle_base,delta,delta_time,elec_price,power,delta_dot,charger_num_depot)


event_mat = depot_vehicle_base{depot};


x = binvar(size(event_mat,1),96,'full');
q = sdpvar(size(event_mat,1),96,'full');
p_kj = sdpvar(size(event_mat,1),96,'full');              
p_j = sdpvar(1,96);
p_max  = sdpvar(1,1);


objective = 0;
objective = objective + lamda_peak*p_max;



elec_price_mat = zeros(size(event_mat,1),96);
for  i = 1:size(event_mat,1)
    for j = 1:96
        elec_price_mat(i,j) = elec_price(j);
    end
end

objective = objective + sum(sum(elec_price_mat.*q));




yueshu = [];
yueshu = [yueshu,x <= delta];
yueshu = [yueshu, q >= 0];
yueshu = [yueshu, p_kj >= 0];
yueshu = [yueshu, p_j >= 0];
yueshu = [yueshu, p_max >= 0];
yueshu = [yueshu, sum(q,2) == event_mat(:,2 + month)];
yueshu = [yueshu, q == (1/60)*delta_time.*p_kj];
yueshu = [yueshu, p_kj <= power*x];




yueshu = [yueshu, p_kj <= power*x];
yueshu = [yueshu, p_j == sum(p_kj,1) ];
yueshu = [yueshu, sum(x,1) <= charger_num_depot(depot)];
yueshu = [yueshu, p_max >= p_j ];
ops = sdpsettings('solver','+gurobi');
ops.gurobi.TimeLimit = 300;
sol = optimize(yueshu,objective,ops);


p_t = zeros(1,1440);
p_kj = double(p_kj);
for t = 1:1440
    sum1 = 0;
    for i = 1:size(event_mat,1)
        for j = 1:96
            sum1 = sum1 + delta_dot(i,j,t)*p_kj(i,j);   %%%%%%%%%%%%%%%  
        end
    end
    p_t(t) = sum1;
end

            
x = double(x);

for i = 1:20992
    ss{i} = [];
end

for i = 1:size(event_mat,1)
    mat =  ss{event_mat(i,15)};
    for j = 1:96
        if x(i,j) == 1
           mat = [mat;event_mat(i,16),j];
        end
    end
    ss{event_mat(i,15)} = mat;
end
            
            
            
            
            
