%%%%% Output  bus charging load at each bus depot
function [depot_load,bus_occupancy_cell] = bus_charging_schedule_depot(bus_occupancy_cell,lamda_peak,depot,depot_vehicle_base,elec_price,power,charger_num_depot)


event_mat = depot_vehicle_base{depot};
delta = zeros(size(event_mat,1),96);


for i = 1:size(event_mat,1)
    for j = 1:96
        if event_mat(i,1) <= event_mat(i,2)
           x1 = ceil(  (event_mat(i,1) + 1 ) /60);
           x2 = ceil((event_mat(i,2) + 1 )/60);
           y1 = ceil(x1/15);
           y2 = ceil(x2/15); 
           delta(i,y1:y2) = 1;
        else
            x1 = ceil(  (event_mat(i,1) + 1 )  /60);
            y1 = ceil(x1/15);
            delta(i,y1:96) = 1;
        
            x2 = ceil((event_mat(i,2) + 1 )/60);
            y2 = ceil(x2/15);
            delta(i,1:y2) = 1;
        end
    end
end



delta_time = zeros(size(event_mat,1),96);
delta_dot = zeros(size(event_mat,1),96,1440);
for i = 1:size(event_mat,1)
    for j = 1:96
        if delta(i,j) == 1
            j_left =  15*(j - 1) + 1;
            j_right =  15*j;
            
            if event_mat(i,1) <= event_mat(i,2)
                if ceil(  (event_mat(i,1) + 1 ) /60) >= j_left   && ceil((event_mat(i,2) + 1 )/60) <=  j_right  %%% 第一种情况 两端都在内
                    delta_time(i,j) = ceil((event_mat(i,2) + 1 )/60) - ceil(  (event_mat(i,1) + 1 ) /60) + 1 ;
                    delta_dot(i,j,ceil(  (event_mat(i,1) + 1 ) /60):ceil((event_mat(i,2) + 1 )/60)) =  1;
                end
                if  ceil(  (event_mat(i,1) + 1 ) /60) < j_left  && ceil((event_mat(i,2) + 1 )/60) > j_right %%% 第二种情况 两端都在外
                    delta_time(i,j) = 15;
                    delta_dot(i,j,j_left:j_right) =  1; 
                end
                
                if  ceil(  (event_mat(i,1) + 1 ) /60) < j_left   &&  ceil((event_mat(i,2) + 1 )/60) <=  j_right %%% 第三种情况 右端都在内 左端在外
                    delta_time(i,j) =  ceil((event_mat(i,2) + 1 )/60) -  j_left + 1;
                    delta_dot(i,j,j_left:ceil((event_mat(i,2) + 1 )/60)) =  1; 
                end
                if  ceil(  (event_mat(i,1) + 1 ) /60) >= j_left   && ceil((event_mat(i,2) + 1 )/60)  >  j_right %%% 第四种情况 右端都在外 左端在内
                    delta_time(i,j) = j_right - ceil(  (event_mat(i,1) + 1 ) /60) + 1;
                    delta_dot(i,j,ceil(  (event_mat(i,1) + 1 ) /60):j_right) =  1; 
                end
            else
                x1 = ceil(  (event_mat(i,1) + 1 ) /60);
                x2 = ceil((event_mat(i,2) + 1 )/60);
                y1 = ceil(x1/15);
                y2 = ceil(x2/15);
                if  j >=  y1 &&  j<= 96
                    if  ceil(  (event_mat(i,1) + 1 ) /60) >= j_left  && 1440 <=  j_right  %%% 第一种情况 两端都在内
                        delta_time(i,j) =   1440 - ceil(  (event_mat(i,1) + 1 ) /60) + 1;
                        delta_dot(i,j,ceil(  (event_mat(i,1) + 1 ) /60):1440) =  1;
                 
                        
                    end
                    if  ceil(  (event_mat(i,1) + 1 ) /60) < j_left   && 1440  > j_right %%% 第二种情况 两端都在外
                        delta_time(i,j) = 15;
                        delta_dot(i,j,j_left:j_right) =  1; 
                 
                    end
                    if  ceil((event_mat(i,1) + 1 ) /60) < j_left   && 1440  <=  j_right %%% 第三种情况 右端都在内 左端在外
                        delta_time(i,j) = 1440 -  j_left + 1;
                        delta_dot(i,j,j_left:1440) =  1; 
                        
   
                    end
                    if  ceil((event_mat(i,1) + 1 ) /60)  >= j_left   && 1440 >  j_right %%% 第四种情况 右端都在外 左端在内
                        delta_time(i,j) = j_right - ceil((event_mat(i,1) + 1 ) /60) + 1;
                        delta_dot(i,j,ceil(  (event_mat(i,1) + 1 ) /60):j_right) =  1; 
                        
            
                    end
                end
                if j >= 1 && j <= y2
                    if 1 >= j_left   && ceil((event_mat(i,2) + 1 )/60)  <=  j_right  %%% 第一种情况 两端都在内
                        delta_time(i,j) =   ceil((event_mat(i,2) + 1 )/60) - 1 + 1;
                        delta_dot(i,j,1:ceil((event_mat(i,2) + 1 )/60)) =  1;
                     
                    end
                    
                    if  1 < j_left   && ceil((event_mat(i,2) + 1 )/60)  > j_right %%% 第二种情况 两端都在外
                        delta_time(i,j) = 15;
                        delta_dot(i,j,j_left:j_right) =  1; 
                        
                        
                    end
                    if  1 < j_left   && ceil((event_mat(i,2) + 1 )/60)  <=  j_right %%% 第三种情况 右端都在内 左端在外
                        delta_time(i,j) = ceil((event_mat(i,2) + 1 )/60) -  j_left + 1;
                        delta_dot(i,j,j_left:ceil((event_mat(i,2) + 1 )/60)) =  1; 
                        
                        
                        
                        
                        
                    end
                    if  1 >= j_left   && ceil((event_mat(i,2) + 1 )/60)  >  j_right %%% 第四种情况 右端都在外 左端在内
                        delta_time(i,j) = j_right - 1 + 1;
                        delta_dot(i,j,1:j_right) =  1;
                    end
                end
            end
        end
    end
end




























%%%%%%%%%%%%%%%%%%%%%%%%
depot_load = zeros(12,1440);
add_cell = {};
parfor m = 1:12
    [s1,s2] = month_schedule(m,lamda_peak,depot,depot_vehicle_base,delta,delta_time,elec_price,power,delta_dot,charger_num_depot);
    depot_load(m,:) = s1;
    add_cell{m} = s2;
end





for i = 1:20992
    for j = 1:12
        mat1 =  bus_occupancy_cell{i,j}; 
        mat2 = add_cell{j};
        mat3 = mat2{i};
        mat1 = [mat1;mat3];
        bus_occupancy_cell{i,j} = mat1 ;
    end
end

       
        
        



















%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                


















