%%%Input  charging_shedule
%%%Output  charger_num_depot (The number of chargers required at bus each bus depot)
depot_vehicle = {};
for i = 1:678
    depot_vehicle{i} = [];
end

for i = 1:20992
    cell_base = charging_shedule{i};
    if ~isempty(cell_base)
        mat = cell_base{12};
        for j = 1:size(mat,1)
            xxx = depot_vehicle{mat(j,5)};
            xxx = [xxx; mat(j,2),mat(j,3),max(mat(j,9),0)];
            depot_vehicle{mat(j,5)} = xxx;
        end
    end
end

for i = 1:678
     if ~isempty(depot_vehicle{i})
         mat = depot_vehicle{i};
         [time_list,order_list] =  sort(mat(:,1));
         mat_new = [];
         for j = 1:size(mat,1)
             mat_new = [mat_new;mat(order_list(j),:)];
         end
         depot_vehicle{i} =  mat_new;
     end
end



for i = 1:678
    if ~isempty(depot_vehicle{i})
        mat = depot_vehicle{i};
        for j = 1:size(mat,1)
           if mat(j,1) <= mat(j,2)
               if  mat(j,3) >  ((mat(j,2) - mat(j,1) + 1)/3600)*power
                   
                   real_time =  ceil( ( mat(j,3)/power )*3600) ;
                   deta = real_time - (mat(j,2) - mat(j,1) + 1);
                   if deta + mat(j,2) <= 86399
                       mat(j,2) = deta + mat(j,2);
                   else
                       mat(j,2) =  deta + mat(j,2) - 86400;
                   end
               end
           else
              if  mat(j,3) >  ((86399 - mat(j,1) + 1  + mat(j,2) + 1 )/3600)*power
                  real_time =  ceil((mat(j,3)/power)*3600) ;
                  deta =  (86399 - mat(j,1) + 1) + mat(j,2) + 1;
                  mat(j,2) =  deta + mat(j,2);
              end
           end
        end
        depot_vehicle{i} = mat;
        
    end
end

                
                




charger_num_depot = zeros(1,678);
for i = 1:678   
    i
    if ~isempty(depot_vehicle{i})
        charger_num = 1;
        mat = depot_vehicle{i};
        while true
            if charger_num > 500
                charger_num = charger_num_depot_base(i);
                break
            end
            occupied_charger = zeros(1,96);
            for j = 1:size(mat,1)
                charging_time = floor((mat(j,3)/power)*3600);
                
                if mat(j,1) <= mat(j,2)
                    flag = 0;
                    for t = mat(j,1) : mat(j,2) - charging_time + 1
                        left_interval = ceil((t + 1)/900);
                        right_interval = ceil((t + charging_time - 1 + 1)/900);
                        flag = 1;
                        for k = left_interval : right_interval
                            if occupied_charger(k) == charger_num
                                flag = 0;
                                break
                            end
                        end
                        if   flag == 1
                            occupied_charger(left_interval : right_interval) = occupied_charger(left_interval : right_interval) + 1;
                            break
                        end
                    end
                    if  flag == 0
                        charger_num = charger_num + 1;
                        break
                    end
                end
                
                if mat(j,1) > mat(j,2)
                    flag = 0;
                    for t = 1: ((86399 -  mat(j,1) + 1) + mat(j,2) + 1) - charging_time + 1
                        % case 1
                        if t + mat(j,1) - 1  <= 86399 && t + mat(j,1) - 1 + charging_time - 1 <= 86399
                            left_interval = ceil((t + mat(j,1) - 1  + 1)/900);
                            right_interval = ceil((t + mat(j,1) - 1 + charging_time - 1 + 1)/900);
                            flag = 1;
                            for k = left_interval : right_interval
                                if occupied_charger(k) == charger_num
                                    flag = 0;
                                    break
                                end
                            end
                            if   flag == 1
                                occupied_charger(left_interval : right_interval) = occupied_charger(left_interval : right_interval) + 1;
                                break
                            end
                        end
                        
                        if t + mat(j,1) - 1 > 86399 && t + mat(j,1) - 1 + charging_time - 1 > 86399
                            left_interval = ceil((t + mat(j,1) - 1 - 86399  )/900);
                            right_interval = ceil((t + mat(j,1) - 1 + charging_time - 1 - 86399)/900);
                            flag = 1;
                            for k = left_interval : right_interval
                                if occupied_charger(k) == charger_num
                                    flag = 0;
                                    break
                                end
                            end
                            if   flag == 1
                                occupied_charger(left_interval : right_interval) = occupied_charger(left_interval : right_interval) + 1;
                                break
                            end
                        end
                        
                        
                        if t + mat(j,1) - 1 <= 86399 && t + mat(j,1) - 1 + charging_time - 1 > 86399
                            left_interval = ceil((t + mat(j,1) - 1  + 1)/900);
                            right_interval = ceil((t + mat(j,1) - 1 + charging_time - 1 - 86399 )/900);
                            flag = 1;
                            for k = left_interval : 96
                                if occupied_charger(k) == charger_num
                                    flag = 0;
                                    break
                                end
                            end
                            for k = 1 : right_interval
                                if occupied_charger(k) == charger_num
                                    flag = 0;
                                    break
                                end
                            end
                            if   flag == 1
                                occupied_charger(left_interval : 96) = occupied_charger(left_interval : 96) + 1;
                                occupied_charger(1 : right_interval) = occupied_charger(1 : right_interval) + 1;
                                break
                            end
                        end
                    end
                    if  flag == 0
                        charger_num = charger_num + 1;
                        break
                    end
                end
   
            end
           
            if flag == 1
                break
            end
            
        end
        charger_num_depot(i) = charger_num;
        
    end
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

depot_vehicle_base = {};
for i = 1:678
    depot_vehicle_base{i} = [];
end

for i = 1:20992
    cell_base = charging_shedule{i};
    if ~isempty(cell_base)
        mat_base = cell_base{12};
        for j = 1:size(mat_base,1)
            xxx = depot_vehicle_base{mat_base(j,5)};
            xxx = [xxx; mat_base(j,2),mat_base(j,3),zeros(1,14)];
            for m = 1:12
                mat_new = cell_base{m};
                xxx(size(xxx,1),2 + m) = max(mat_new(j,9),0);
            end 
            xxx(size(xxx,1),15:16) = [i,j];
            depot_vehicle_base{mat_base(j,5)} = xxx; 
        end 
    end
end
for i = 1:678
     if ~isempty(depot_vehicle_base{i})
         mat = depot_vehicle_base{i};
         [time_list,order_list] =  sort(mat(:,1));
         mat_new = [];
         for j = 1:size(mat,1)
             mat_new = [mat_new;mat(order_list(j),:)];
         end
         depot_vehicle_base{i} =  mat_new;
     end
end




for i = 1:678
    if ~isempty(depot_vehicle_base{i})
        mat = depot_vehicle_base{i};
        for j = 1:size(mat,1)
           if mat(j,1) <= mat(j,2)
               if  mat(j,14) >  ((mat(j,2) - mat(j,1) + 1)/3600)*power
                   
                   real_time =  ceil( ( mat(j,14)/power )*3600);
                   deta = real_time - (mat(j,2) - mat(j,1) + 1);
                   if deta + mat(j,2) <= 86399
                       mat(j,2) = deta + mat(j,2);
                   else
                       mat(j,2) =  deta + mat(j,2) - 86400;
                   end
               end
           else
              if  mat(j,14) >  ((86399 - mat(j,1) + 1  + mat(j,2) + 1 )/3600)*power
                  real_time =  ceil((mat(j,14)/power)*3600);
                  deta =  (86399 - mat(j,1) + 1) + mat(j,2) + 1;
                  mat(j,2) =  deta + mat(j,2);
              end
           end
        end
        depot_vehicle_base{i} = mat;
        
    end
end

                
       







